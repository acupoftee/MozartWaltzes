package org.jfugue.experiments;

import org.jfugue.provider.NoteProviderFactory;
import org.jfugue.theory.Note;
import org.staccato.PreprocessorFunction;
import org.staccato.StaccatoParserContext;

public class GuitarSlideFunction implements PreprocessorFunction {
    private static GuitarSlideFunction instance;
    
    private GuitarSlideFunction() { }
    
    public static GuitarSlideFunction getInstance() {
        if (instance == null) {
            instance = new GuitarSlideFunction();
        }
        return instance;
    }
    
    @Override
    public String apply(String parameters, StaccatoParserContext context) {
        StringBuilder buddy = new StringBuilder();
        for (String noteString : parameters.split(" ")) {
            try {
                Note note = NoteProviderFactory.getNoteProvider().createNote(noteString);
                int n = (int)(note.getDuration() / THIRTY_SECOND_DURATION);
                for (int i=0; i < n/2; i++) {
                    buddy.append(Note.getToneString((byte)note.getValue()));
                    buddy.append("t ");
                    // This function could really be more intelligent. For example, 
                    // in the following line, the value of the trill note should actually
                    // be consistent with the scale that is being used, and the note that
                    // is being played. In a C-Major scale with an E note, F would be the
                    // trill note, and that is only +1 from E. Also, the trill could become
                    // increasingly quick. 
                    buddy.append(Note.getToneString((byte)(note.getValue() + 2))); 
                    buddy.append("t ");
                }
            } catch (Exception e) {
                // Nothing to do
            }
        }
        return buddy.toString().trim();
    }

    @Override
    public String[] getNames() {
        return NAMES;
    }
    
    private static final String[] NAMES = { "TRILL", "TR" };
    private static final double THIRTY_SECOND_DURATION = 1/32D;
}
