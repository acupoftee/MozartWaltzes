package org.jfugue.experiments;

public class GuitarFunctions {

}
