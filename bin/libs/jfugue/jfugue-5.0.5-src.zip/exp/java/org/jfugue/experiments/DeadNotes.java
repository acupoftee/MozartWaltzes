package org.jfugue.experiments;

import java.util.HashMap;

import org.jfugue.pattern.Pattern;
import org.jfugue.player.Player;
import org.staccato.ReplacementMapPreprocessor;
import org.staccato.StaccatoParserContext;

public class DeadNotes {
    public static void main(String[] args) {
        ReplacementMapPreprocessor.getInstance().setReplacementMap(new HashMap<String, String>() {{ put("dead", "a0d0"); }} );
        Pattern pattern = new Pattern ("I[Acoustic_Bass] E4q E4q<dead> E4q E4q<dead>");
        String preprocess = ReplacementMapPreprocessor.getInstance().preprocess(pattern.toString(), (StaccatoParserContext)null);
        System.out.println(preprocess);
        
//        Pattern pattern = new Pattern ("T120 V0 I[Acoustic_Bass] E4i E4s<dead> E4s<dead> | E4i E4s<dead> E4s<dead> | E4i D4i E4i G4i | E4i E4s<dead> E4s<dead> | E4i E4s<dead> E4s<dead> | E4i G4i E4i D4i Rq");
//        Player player = new Player();
//        player.play(pattern);
    }
}
