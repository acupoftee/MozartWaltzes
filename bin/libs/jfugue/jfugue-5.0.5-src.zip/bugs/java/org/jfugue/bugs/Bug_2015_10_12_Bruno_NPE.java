package org.jfugue.bugs;

import javax.sound.midi.MidiUnavailableException;

import org.jfugue.player.Player;
import org.jfugue.realtime.RealtimePlayer;
import org.jfugue.theory.Note;

/**
 * What bruno grandjean is seeing:
 * 
 * Exception in thread "Thread-16" java.lang.NullPointerException
    at org.jfugue.midi.MidiEventManager.addMetaMessage(MidiEventManager.java:179)
    at org.jfugue.midi.MidiEventManager.setTempo(MidiEventManager.java:108)
    at org.jfugue.midi.MidiParserListener.onTempoChanged(MidiParserListener.java:78)
    at org.jfugue.parser.Parser.fireTempoChanged(Parser.java:93)
    at org.staccato.TempoSubparser.parse(TempoSubparser.java:63)
    at org.staccato.StaccatoParser.parse(StaccatoParser.java:118)
    at org.jfugue.player.Player.getSequence(Player.java:65)
    at org.jfugue.player.Player.play(Player.java:82)
    at org.jfugue.player.Player.play(Player.java:74)
    at builders.players.PlayerBuilder.play(PlayerBuilder.java:35)
    at builders.players.PlayerBuilder.run(PlayerBuilder.java:45)
    at java.lang.Thread.run(Unknown Source)
 *
 */
public class Bug_2015_10_12_Bruno_NPE {
    public static void main(String[] args) {
        Player player = new Player();
        player.play("T100 V0 I0 69q 71q T100 V1 I0 Rq Rq T100 V2 I0 Rq Rq T100 V3 I0 Rq Rq ");
    }
}
