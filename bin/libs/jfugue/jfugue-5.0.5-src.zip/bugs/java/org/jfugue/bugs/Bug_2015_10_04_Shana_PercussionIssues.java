package org.jfugue.bugs;

import javax.sound.midi.MidiUnavailableException;

import org.jfugue.realtime.RealtimePlayer;
import org.jfugue.theory.Note;

public class Bug_2015_10_04_Shana_PercussionIssues {
    public static void main(String[] args) {
        RealtimePlayer player=null;
        try {
            player = new RealtimePlayer();
            player.play("T120 V9 [HAND_CLAP]I RI [PEDAL_HI_HAT]S RS RI [PEDAL_HI_HAT]S RS RI [PEDAL_HI_HAT]S RS RI [HAND_CLAP]I RI [PEDAL_HI_HAT]I RI [HAND_CLAP]I RI [PEDAL_HI_HAT]I RI");
            Thread.sleep(4000);
        } catch (MidiUnavailableException ex) {
            ex.printStackTrace();
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        } finally {
            player.close();
        }
    }
}
